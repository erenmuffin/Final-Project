function deleteRow(r) {
    var i = r.parentNode.parentNode.rowIndex;
    document.getElementById("deletetable").deleteRow(i);
}


function deleteRow2(r) {
    var i = r.parentNode.parentNode.rowIndex;
    document.getElementById("deletetable2").deleteRow(i);
}

function editRow(r){
    var i = r.parentNode.parentNode.rowIndex;
    document.getElementById("deletetable").editRowRow(i);

}


