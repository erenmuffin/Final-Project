let form = document.querySelector('form');
form.addEventListener('submit', handleSubmit);
        
    function handleSubmit (event) {
        event.preventDefault();
        let formData = new FormData(form)
        let data = Object.fromEntries(formData)
        let jsonData = JSON.stringify(data)
        console.log(jsonData)
        const fetch = async function () {
            const x = await  fetch('http://10.80.0.14:3000/api/v1/users/signin', {
                method : 'POST',
                headers : {
                    'Content-Type' : 'application/json'
                 },
                body : jsonData
            })
            console.log(x.json())
        }
    }


